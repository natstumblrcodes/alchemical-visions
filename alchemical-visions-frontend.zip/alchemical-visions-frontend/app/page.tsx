"use client";

import { useEffect, useMemo, useState } from "react";

type Mode = "text" | "audio" | "video";
type Screen = "welcome" | "away" | "offline" | "auth" | "portal" | "queue" | "payment";

const rates: Record<Mode, number> = { text: 1.99, audio: 2.99, video: 3.99 };

const Icon = ({ name, size = 24 }: { name: string; size?: number }) => {
  const common = { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.9, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const paths: Record<string, React.ReactNode> = {
    moon: <><path d="M20.6 15.4A8.7 8.7 0 0 1 8.6 3.4 8.8 8.8 0 1 0 20.6 15.4Z"/><path d="M15 3v3M18 4.5l-2 2M21 7h-3"/></>,
    chat: <><path d="M4 5.5h16v10H8l-4 4v-14Z"/><path d="M8 9h8M8 12h5"/></>,
    video: <><rect x="3" y="5" width="13" height="14" rx="2"/><path d="m16 10 5-3v10l-5-3"/></>,
    phone: <path d="M7.2 4.5 9.5 8 7.7 9.7c1.1 2.5 3.1 4.5 5.6 5.6l1.7-1.8 3.5 2.3-1 2.4c-.4 1-1.5 1.5-2.5 1.2C8.8 17.7 6.3 15.2 4.6 9c-.3-1 .2-2.1 1.2-2.5l1.4-.6Z"/>,
    user: <><circle cx="12" cy="7.5" r="3.5"/><path d="M5 21c.5-4 3-6 7-6s6.5 2 7 6"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 9h18M7 13h3M14 13h3M7 17h3"/></>,
    card: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19 13.5a7.7 7.7 0 0 0 0-3l2-1.5-2-3.4-2.3 1a8.1 8.1 0 0 0-2.6-1.5L13.8 2h-3.6l-.4 3.1a8.1 8.1 0 0 0-2.6 1.5l-2.3-1-2 3.4 2 1.5a7.7 7.7 0 0 0 0 3l-2 1.5 2 3.4 2.3-1a8.1 8.1 0 0 0 2.6 1.5l.4 3.1h3.6l.4-3.1a8.1 8.1 0 0 0 2.6-1.5l2.3 1 2-3.4-2-1.5Z"/></>,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></>,
    home: <><path d="m3 11 9-8 9 8v9H3v-9Z"/><path d="M9 20v-6h6v6"/></>,
    send: <path d="m4 4 17 8-17 8 3.5-8L4 4Zm3.5 8H21"/>,
    paperclip: <path d="m8 12 5.5-5.5a3 3 0 0 1 4.2 4.2l-7.4 7.4a4.5 4.5 0 0 1-6.4-6.4l7.7-7.7"/>,
    hourglass: <><path d="M6 3h12M6 21h12M7 3c0 4 2 5 5 7-3 2-5 3-5 7M17 3c0 4-2 5-5 7 3 2 5 3 5 7"/></>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    lock: <><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    eye: <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></>,
    login: <><path d="M10 17l5-5-5-5M15 12H3M13 4h6v16h-6"/></>,
    plususer: <><circle cx="9" cy="8" r="3.5"/><path d="M2.5 21c.5-4 2.7-6 6.5-6 2.4 0 4.2.8 5.3 2.4M18 8v6M15 11h6"/></>,
    check: <path d="m5 12 4 4L19 6"/>,
    bell: <><path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9Z"/><path d="M10 21h4"/></>,
  };
  return <svg {...common}>{paths[name] ?? paths.chat}</svg>;
};

function OrnateHeader({ mode, balance, timer }: { mode: Mode; balance: number; timer: string }) {
  return (
    <header className="portal-header">
      <div className="brand-mark"><Icon name="moon" size={45}/></div>
      <div className="brand-wordmark"><div>✦ ALCHEMICAL ✦</div><strong>VISIONS</strong></div>
      <div className="balance-box">
        <div className="balance">${balance.toFixed(2)}</div>
        <div className="timer">{timer}</div>
        <div className="balance-label">Remaining Balance</div>
      </div>
      <div className="gold-rule" />
    </header>
  );
}

function ModeTabs({ mode, setMode }: { mode: Mode; setMode: (m: Mode) => void }) {
  return <div className="mode-tabs">
    {(["text", "video", "audio"] as Mode[]).map((m) => <button key={m} className={mode === m ? "mode active" : "mode"} onClick={() => setMode(m)}>
      <Icon name={m === "text" ? "chat" : m === "video" ? "video" : "phone"} size={26}/>
      <span>{m === "text" ? "Text Chat" : m === "video" ? "Video Chat" : "Audio Call"}</span>
    </button>)}
  </div>;
}

function BottomTools() {
  const items = [["user", "Profile"], ["calendar", "Schedule"], ["calendar", "Book Followup\nAppointment"], ["mail", "Contact Me"], ["card", "Billing Info"], ["settings", "Settings"]] as const;
  return <div className="tool-grid">{items.map(([icon, label]) => <button key={label}><Icon name={icon} size={26}/><span>{label.split("\n").map((x,i)=><span key={i}>{x}{i === 0 && label.includes("\n") ? <br/>: null}</span>)}</span></button>)}</div>;
}

function Portal({ mode, setMode, balance, active, onStart }: { mode: Mode; setMode: (m: Mode) => void; balance: number; active: boolean; onStart: () => void }) {
  const [messages, setMessages] = useState<string[]>(["Automated Portal Attendant: Your session will start momentarily. Please take the next five minutes to fill out the Profile section while you wait. You will not be charged until the session begins. Thank you!"]);
  const [draft, setDraft] = useState("");
  const timer = active ? "00:04:32" : "00:00:00";
  const send = () => { if (!draft.trim()) return; setMessages((m) => [...m, draft.trim()]); setDraft(""); };
  return <main className="app-shell">
    <OrnateHeader mode={mode} balance={balance} timer={timer}/>
    <ModeTabs mode={mode} setMode={setMode}/>
    <section className={`session-stage ${mode}`}>
      {mode === "text" && <div className="chat-panel">
        <div className="constellation-row">✦　☼　✦　☾　✦　☼　✦</div>
        <div className="message-scroll">{messages.map((m,i)=><p key={i} className={i === 0 ? "attendant" : "mine"}>{m}</p>)}</div>
        {active && <button className="end-call" onClick={onStart}>☎　End Session</button>}
      </div>}
      {mode === "audio" && <div className="call-panel audio-panel">
        <div className="call-art">☾<div className="call-glyph">☎</div><div className="call-stars">✦　✧　✦</div></div>
        <div className="call-title">{active ? "Your Call Is Connected" : "Ready to Begin Your Session"}</div>
        <div className="call-time">{timer}</div>
        <button className="end-call" onClick={onStart}>{active ? "☎　End Call" : "✦　Begin Session　✦"}</button>
      </div>}
      {mode === "video" && <div className="call-panel video-panel">
        <div className="video-placeholder"><Icon name="user" size={100}/><div className="self-view"><Icon name="user" size={40}/></div></div>
        <div className="video-controls"><button><Icon name="phone"/></button><button className="end-call" onClick={onStart}>{active ? "☎　End Call" : "✦　Begin Session　✦"}</button><button><Icon name="video"/></button></div>
      </div>}
    </section>
    {mode === "text" && <div className="composer"><button><Icon name="paperclip" size={23}/></button><input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key === "Enter" && send()} placeholder="Type a message..."/><button onClick={send}><Icon name="send" size={23}/></button></div>}
    <BottomTools/>
    <button className="purchase" onClick={() => alert("Payment flow will connect to Stripe here.")}><Icon name="hourglass" size={30}/>Purchase Additional Time<Icon name="hourglass" size={30}/></button>
  </main>;
}

function Landing({ setScreen }: { setScreen: (s: Screen) => void }) {
  return <main className="app-shell landing">
    <OrnateHeader mode="text" balance={0} timer="00:00:00"/>
    <ModeTabs mode="text" setMode={()=>{}}/>
    <section className="landing-card">
      <div className="celestial">☾　✦　☼　✦　☾</div>
      <h1>Thank You</h1>
      <h2>for Visiting Alchemical Visions!</h2>
      <div className="ornament">— ✦ ☾ ✦ —</div>
    </section>
    <button className="primary-button" onClick={()=>setScreen("auth")}><Icon name="login" size={30}/> Sign In Again</button>
    <button className="secondary-button"><Icon name="home" size={28}/> Return to Homepage</button>
  </main>;
}

function StatusScreen({ kind, setScreen }: { kind: "away" | "offline" | "queue"; setScreen: (s: Screen)=>void }) {
  const away = kind === "away";
  const queue = kind === "queue";
  return <main className="app-shell status-screen">
    <OrnateHeader mode="text" balance={0} timer="00:00:00"/>
    <ModeTabs mode="text" setMode={()=>{}}/>
    <section className="status-art">
      <div className="status-stars">✦　☾　✧　☼　✦</div>
      {queue ? <><h1>⌛ In Queue</h1><h2>Estimated Wait Time</h2><div className="wait">&gt; 5 Minutes Remaining</div><p>You are in line for the next available reader.<br/>Thank you for your patience!</p></> : <><h1>Alchemical Visions</h1><h2>is Currently {away ? "Away" : "Offline"}!</h2><div className="ornament">— ✦ ☾ ✦ —</div><p>Provide your email address below if you'd like<br/>to be notified {away ? "upon my next return" : "whenever I'm signed in online"}!</p><div className="notify"><input placeholder="✉  Email Address"/><button>Submit</button></div></>}
    </section>
    <button className="primary-button" onClick={()=>setScreen("portal")}><Icon name="calendar" size={28}/>{queue ? "Continue Waiting" : "Book Appointment"}</button>
    <button className="secondary-button" onClick={()=>setScreen("welcome")}><Icon name="home" size={28}/> Return Home</button>
  </main>;
}

function Auth({ setScreen }: { setScreen: (s: Screen)=>void }) {
  const [register, setRegister] = useState(false);
  return <main className="app-shell auth-screen">
    <OrnateHeader mode="text" balance={0} timer="00:00:00"/>
    <section className="auth-art"><div className="status-stars">✦　☾　✦　✧　☼　✦</div><h1>{register ? "Create Your Account" : "Welcome"}</h1><h2>{register ? "Join Alchemical Visions" : "Sign in to Continue"}</h2><div className="ornament">— ✦ ☾ ✦ —</div></section>
    <div className="form-card">
      {register && <label><Icon name="user"/> <input placeholder="Username"/></label>}
      <label><Icon name="mail"/> <input placeholder="Email Address" type="email"/></label>
      <label><Icon name="lock"/> <input placeholder="Password" type="password"/></label>
      {register && <label><Icon name="lock"/> <input placeholder="Confirm Password" type="password"/></label>}
      <button className="primary-button" onClick={()=>setScreen("portal")}><Icon name={register ? "plususer" : "login"}/>{register ? "Create Account" : "Sign In"}</button>
      {!register && <div className="auth-links"><span>☑ Remember Me</span><button>Forgot Password?</button></div>}
      <button className="secondary-button" onClick={()=>setRegister(!register)}><Icon name="plususer"/>{register ? "Back to Sign In" : "Create Your Account"}</button>
    </div>
  </main>;
}

function Payment({ setScreen }: { setScreen: (s: Screen)=>void }) {
  return <main className="app-shell payment-screen">
    <OrnateHeader mode="text" balance={0} timer="00:00:00"/>
    <section className="payment-art"><div className="status-stars">✦　☾　✧　✦</div><h1>Enter Your<br/>Payment Details</h1><div className="ornament">— ☾ —</div></section>
    <div className="form-card payment-form">
      <label><Icon name="card"/><input placeholder="Card Number" inputMode="numeric"/></label>
      <div className="two-inputs"><label><Icon name="calendar"/><input placeholder="MM / YY"/></label><label><Icon name="lock"/><input placeholder="CVV"/></label></div>
      <label><Icon name="user"/><input placeholder="Name on Card"/></label>
      <div className="secure">☑ Save this card for future sessions</div>
      <button className="primary-button" onClick={()=>setScreen("portal")}><Icon name="card"/> Pay &amp; Start Session</button>
      <button className="secondary-button" onClick={()=>setScreen("portal")}><Icon name="arrow"/> Back to Payment Options</button>
    </div>
  </main>;
}

export default function Home() {
  const [screen, setScreen] = useState<Screen>("welcome");
  const [mode, setMode] = useState<Mode>("text");
  const [balance, setBalance] = useState(0);
  const [active, setActive] = useState(false);

  useEffect(() => { const stored = localStorage.getItem("av-demo-balance"); if (stored) setBalance(Number(stored)); }, []);
  useEffect(() => { localStorage.setItem("av-demo-balance", String(balance)); }, [balance]);

  const content = useMemo(() => {
    if (screen === "welcome") return <Landing setScreen={setScreen}/>;
    if (screen === "auth") return <Auth setScreen={setScreen}/>;
    if (screen === "away" || screen === "offline" || screen === "queue") return <StatusScreen kind={screen} setScreen={setScreen}/>;
    if (screen === "payment") return <Payment setScreen={setScreen}/>;
    return <Portal mode={mode} setMode={setMode} balance={balance} active={active} onStart={()=>setActive(v=>!v)}/>;
  }, [screen, mode, balance, active]);

  return <div className="page-wrap">
    <div className="demo-nav">
      <span>Alchemical Visions • Front-End Preview</span>
      <div><button onClick={()=>setScreen("welcome")}>Welcome</button><button onClick={()=>setScreen("auth")}>Sign In</button><button onClick={()=>setScreen("away")}>Away</button><button onClick={()=>setScreen("offline")}>Offline</button><button onClick={()=>setScreen("queue")}>Queue</button><button onClick={()=>setScreen("portal")}>Portal</button><button onClick={()=>setScreen("payment")}>Payment</button></div>
    </div>
    {content}
  </div>;
}
