# Alchemical Visions Front-End

A mobile-first front-end recreation based on the supplied Alchemical Visions reference screens.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Demo navigation

The small preview navigation at the top lets you jump between Welcome, Sign In, Away, Offline, Queue, Portal and Payment states. The buttons are only for previewing the UI; Supabase/Stripe/WebRTC wiring should be connected next.
